# API de Acambapan (Web API de la panadería)

Servicio PHP 8 + MySQL que expone la base `pantradicion_db` para la app Android
Acambapan. La app **nunca** habla directo con MySQL: todo pasa por aquí y queda
una copia local en Room.

- **Carpeta:** `C:\xampp\virtualhost\panaderia`
- **API:** `C:\xampp\virtualhost\panaderia\api`
- **URL pública (la que usa la app):** **`https://acambapan.devnoway.com/api/`**
- **Cómo se publica:** túnel de Cloudflare `ch1984` → `http://localhost:88`
- **URL local:** `http://127.0.0.1:88/api/` · desde el emulador: `http://10.0.2.2:88/api/`
- **vhost:** puerto **88**, `ServerName panaderia.local`, `ServerAlias acambapan.devnoway.com`, document root en la carpeta `api/`
- **Base de datos:** `pantradicion_db` (MySQL/MariaDB de XAMPP, usuario `root` sin contraseña)

## Puesta en marcha

1. Importar la base (si ya existe, se recrea):

   ```bat
   C:\xampp\mysql\bin\mysql.exe -u root --default-character-set=utf8mb4 -e "source C:/xampp/virtualhost/panaderia/database/panaderia.sql"
   ```

   El `--default-character-set=utf8mb4` importa: sin él, los acentos y emojis se
   guardan con doble codificación en Windows.

2. Comprobar la configuración de Apache y **reiniciar** (hace falta para cargar
   el `Listen 88`; requiere permisos de administrador):

   ```bat
   C:\xampp\apache\bin\httpd.exe -t
   C:\xampp\apache\bin\httpd.exe -k restart
   ```

   También sirve detener y arrancar Apache desde el panel de XAMPP.

3. Probar:

   ```bat
   curl http://127.0.0.1:88/api/ping
   ```

   ```json
   {"ok":true,"version":"1.0.0","hora":"...","db":"ok"}
   ```

## Formato de respuesta

Siempre JSON en UTF-8:

```json
{ "ok": true, "productos": [ ... ] }
{ "ok": false, "error": { "codigo": "datos_invalidos", "mensaje": "..." } }
```

Códigos: `200/201` correcto · `400` datos inválidos · `401` sin token o vencido ·
`403` sin permiso · `404` no existe · `409` conflicto de estado · `422` dato no
aceptado · `500` fallo interno (se registra en `api/logs/api.log`).

## Autenticación

`POST /api/auth/login` con `{"correo": "...", "password": "..."}` (acepta correo
o teléfono) devuelve un token HMAC-SHA256 válido **12 horas**:

```
Authorization: Bearer <token>
```

El token no se guarda en el servidor. Los usuarios semilla traen la contraseña
`123456` en texto plano (como venía en el script original); al primer login
correcto la API la regraba con `password_hash()`.

Cuentas de ejemplo:

| Rol | Correo | Contraseña |
| --- | --- | --- |
| ADMIN | `admin@pantradicion.com` | `123456` |
| REPARTIDOR | `luis.reparto@pantradicion.com` | `123456` |
| CLIENTE | `s23120227@alumnos.itsur.edu.mx` | `123456` |

## Endpoints

**Salud**
- `GET /ping` — versión, hora y estado de MySQL (sin token).

**Sesión**
- `POST /auth/login` — `{correo, password}` → `{token, usuario}`.
- `POST /auth/registro` — `{nombre, correo, password, telefono, direccion}` → 201 + sesión.
- `GET /auth/me` — usuario del token.

**Catálogo (público)**
- `GET /categorias`
- `GET /productos?categoriaId=&buscar=&incluirAgotados=`
- `GET /productos/{id}` — ficha + `multimedia` + `tandas`.
- `GET /tandas`

**Pedidos**
- `GET /pedidos?clienteId=&estado=&limite=` — con `clienteId` es público; sin
  filtros exige token ADMIN.
- `GET /pedidos/{folio}`
- `POST /pedidos` — `{folio?, clienteId?, clienteNombre, clienteTelefono,
  tipoEntrega, direccionEntrega?, tipoEmpaque, requiereRebanado?, notasPanadero?,
  costoEnvio, items:[{productoId, cantidad, precioUnitario?}]}`
  El servidor calcula `subtotal` y `total`. El `folio` es **idempotente**: si la
  app reintenta el envío de un pedido que ya existe, responde `200` con el mismo
  pedido en lugar de duplicarlo (por eso los folios creados sin conexión
  empiezan con `APP-`).
- `PUT /pedidos/{folio}/estado` — ADMIN. `{estado, repartidorId?, tiempoEstimado?}`.
  Transiciones válidas: RECIBIDO→EN_PREPARACION→EN_CAMINO→ENTREGADO; cualquiera
  no final →CANCELADO. Devuelve `409` si el salto no se permite.
- `DELETE /pedidos/{folio}` — ADMIN; marca CANCELADO (no borra).

**Inventario**
- `GET /insumos` — público (la app lo cachea para consultarlo sin conexión).
- `POST /insumos`, `PUT /insumos/{id}`, `DELETE /insumos/{id}` — ADMIN.
  `DELETE` responde `409` si el insumo está en una receta (`producto_insumos`).

**Resumen y avisos**
- `GET /resumen` — ADMIN. Pedidos y ventas de hoy, ticket promedio, insumos bajos
  y últimos pedidos.
- `GET /notificaciones?clienteId=` — avisos del cliente.
- `PUT /notificaciones/{id}/leida` — requiere token.

## Estructura

```
panaderia/
  api/
    index.php          router + controladores
    .htaccess          rewrite a index.php, bloquea src/ logs/ *.key *.sql
    secret.key         firma de tokens (48 bytes aleatorios)
    logs/api.log       errores internos
    src/Config.php     credenciales MySQL y constantes
    src/Nucleo.php     PDO, JSON, CORS, rutas, bitácora
    src/Auth.php       token HMAC, roles, contraseñas
  database/panaderia.sql   esquema + datos (10 tablas)
```

## Pruebas ejecutadas

Contra la API real con MySQL (21 comprobaciones, todas en verde):

- `ping`, 12 productos, 4 categorías, 6 tandas, ficha con multimedia.
- Login ADMIN correcto, login con contraseña incorrecta → 401,
  `PUT /insumos/1` sin token → 401.
- Crear pedido → 201 con total calculado; **reenviar el mismo folio → 200 y sin
  duplicado**.
- Cambio de estado válido → 200; salto inválido → 409; repartidor asignado.
- Ajuste de stock → 200 y persistido; borrar insumo en receta → 409; alta y baja
  de un insumo nuevo → 201/200.
- `/resumen` con números del día; notificaciones del cliente; registro de
  cliente → 201 y correo duplicado → 409.

## Si el emulador no alcanza `10.0.2.2`

La app ya no depende de eso: por defecto consume el túnel por HTTPS, que funciona
en el emulador y en cualquier teléfono. Ese camino solo hace falta si quieres
trabajar contra el XAMPP local (sin internet o con el túnel apagado):

1. Permitir `httpd.exe` en el firewall (red privada), o
2. Compilar apuntando al loopback y publicar el puerto con adb:

   ```bat
   adb reverse tcp:88 tcp:88
   gradlew :app:assembleDebug -PapiBaseUrl=http://127.0.0.1:88/api/
   ```

En un teléfono físico en la misma red, usa la IP de la PC:

```bat
gradlew :app:assembleDebug -PapiBaseUrl=http://192.168.1.20:88/api/
```

## Exposición pública

`acambapan.devnoway.com` está abierto a internet, así que conviene tenerlo en
cuenta antes de la revisión:

- Las cuentas semilla usan `123456`. Cámbialas (o desactívalas) antes de dejar el
túnel encendido de forma permanente: son credenciales públicas conocidas.
- `POST /pedidos` es público a propósito (un invitado puede pedir). No hay límite
de peticiones por IP; si el túnel queda fijo, añade rate limiting en Cloudflare.
- Las operaciones de administrador exigen token ADMIN y el rol se revalida en
cada petición.
- `secret.key`, `src/`, `logs/` y los `.sql` responden 403.

## Seguridad desplegada

- `secret.key` está fuera de `src/` y el `.htaccess` lo bloquea (403), igual que
  `api/src/**`, `api/logs/**`, `*.sql`, `*.md` y `*.log`.
- Los errores internos no se filtran: van a `api/logs/api.log`.
- Las operaciones administrativas (estado de pedidos, inventario, resumen)
  exigen token con rol `ADMIN`; el rol se revalida en cada petición contra MySQL.
- Las contraseñas nuevas se guardan con `password_hash()` (bcrypt).
